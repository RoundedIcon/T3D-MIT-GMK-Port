new Material(CommonPlayerFootprint)
{
   diffuseMap[0] = "footprint";
   translucent[0] = true;
};
