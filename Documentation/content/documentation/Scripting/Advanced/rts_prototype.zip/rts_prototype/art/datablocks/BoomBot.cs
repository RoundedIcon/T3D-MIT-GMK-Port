//-----------------------------------------------------------------------------
// Torque Game Engine Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

datablock PlayerData(BoomBotData : DefaultPlayerData)
{
   renderFirstPerson = false;
   emap = true;

   airControl = 0.3;

   jetJumpForce       = 8.3 * 10;
   jetJumpEnergyDrain = 0.6;
   jetMinJumpEnergy   = 0;

   maxForwardSpeed = 24;
   jumpForce = 12.3 * 90;

   //className = Armor;
   shapeFile = "art/shapes/actors/BoomBot/BoomBot.dts";

   boundingBox = "1.1 1.2 2.5";
   pickupRadius = 0.75;

   // Damage location details
   boxNormalHeadPercentage = 0.83;
   boxNormalTorsoPercentage = 0.49;
   boxHeadLeftPercentage = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage = 0;
   boxHeadFrontPercentage = 1;
};

// This is a callback function
// This is automatically called by the engine as part 
// of the AI routine
// %this - The BoomBotData datablock
// %obj - The instance of this datablock (our AI Player)
function BoomBotData::onReachDestination(%this, %obj)
{
   // If there was a decal placed, then it was
   // stored in this %obj variable (see playGui.cs)
   // Erase the decal using the decal manager
   if( %obj.decal > -1 )
      decalManagerRemoveDecal(%obj.decal);
}