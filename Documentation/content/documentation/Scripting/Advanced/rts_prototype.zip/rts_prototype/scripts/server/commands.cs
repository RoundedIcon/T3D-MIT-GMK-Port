//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Misc server commands avialable to clients
//-----------------------------------------------------------------------------

function serverCmdSuicide(%client)
{
   if (isObject(%client.player))
      %client.player.kill("Suicide");
}

function serverCmdPlayCel(%client,%anim)
{
   if (isObject(%client.player))
      %client.player.playCelAnimation(%anim);
}

function serverCmdTestAnimation(%client, %anim)
{
   if (isObject(%client.player))
      %client.player.playTestAnimation(%anim);
}

function serverCmdPlayDeath(%client)
{
   if (isObject(%client.player))
      %client.player.playDeathAnimation();
}

// ----------------------------------------------------------------------------
// Throw/Toss
// ----------------------------------------------------------------------------

function serverCmdThrow(%client, %data)
{
   %player = %client.player;
   if(!isObject(%player) || %player.getState() $= "Dead" || !$Game::Running)
      return;
   switch$ (%data)
   {
      case "Weapon":
         %item = (%player.getMountedImage($WeaponSlot) == 0) ? "" : %player.getMountedImage($WeaponSlot).item;
         if (%item !$="")
            %player.throw(%item);
      case "Ammo":
         %weapon = (%player.getMountedImage($WeaponSlot) == 0) ? "" : %player.getMountedImage($WeaponSlot);
         if (%weapon !$= "")
         {
            if(%weapon.ammo !$= "")
               %player.throw(%weapon.ammo);
         }
      default:
         if(%player.hasInventory(%data.getName()))
            %player.throw(%data);
   }
}

// ----------------------------------------------------------------------------
// Force game end and cycle
// ----------------------------------------------------------------------------

function serverCmdFinishGame()
{
   cycleGame();
}

// ----------------------------------------------------------------------------
// Cycle weapons
// ----------------------------------------------------------------------------

function serverCmdCycleWeapon(%client, %data)
{
   %client.getControlObject().cycleWeapon(%data);
}

// ----------------------------------------------------------------------------
// Unmount current weapon
// ----------------------------------------------------------------------------

function serverCmdUnmountWeapon(%client)
{
   %client.getControlObject().unmountImage($WeaponSlot);
}

// ----------------------------------------------------------------------------
// Zoom reticle
// ----------------------------------------------------------------------------

function serverCmdgetZoomReticle(%client)
{
   %player = %client.player;
   %weapon = (%player.getMountedImage($WeaponSlot) == 0) ? "" : %player.getMountedImage($WeaponSlot).item;
   %reticle = %weapon $= "" ? 'bino.png' : %weapon.zoomReticle;
   commandToClient(%client, 'setZoom', %reticle);
}

// Server command that adjusts camera height
function serverCmdadjustCameraHeight(%client, %adjustment)
{
   // Take the current camera position (a vector)
   // Then add or subtract from the Z element, based on
   // the %adjustment value passed in
   %client.camera.position = VectorAdd(%client.camera.position, "0 0 " @ %adjustment);
}

function serverCmdRTSOrbit(%client)
{
   %client.camera.setOrbitObject(%client.player, mDegToRad(30) @ " 0 0", 0, 25, 25);
}

function serverCmdRTSOverhead(%client)
{
   %client.camera.position = VectorAdd(%client.camera.position, "0 0 5" );
   %client.camera.lookAt(%client.player.position);
   %client.camera.controlMode = "Overhead";
}
